
// const BASEURL ="http://localhost:8001/v1"                //Local server connect
const BASEURL ="https://wintech-backend.vercel.app/v1"              //live server connect



export default BASEURL